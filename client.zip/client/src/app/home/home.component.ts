import { Component, OnInit } from '@angular/core';
import { DatePipe } from '@angular/common';
 
import { User, ToDo } from '../_models/index';
import { TodoService } from '../_services/index';

declare var $:any;
 
@Component({
    moduleId: module.id,
    templateUrl: 'home.component.html',
    styleUrls: ['./home.component.css']
})
 
export class HomeComponent implements OnInit {
    currentUser: User;
    todos: ToDo[] = [];
    model: any = {};
    successMessage: string;
    errorMessage: string;
    edit: any;
    view: any;
    removeToDoID: number;
 
    constructor(private todoService: TodoService,
        private datePipe: DatePipe) {
        this.currentUser = JSON.parse(localStorage.getItem('currentUser'));
    }
 
    ngOnInit() {
        this.loadAllTodos();
    }
 
    private loadAllTodos() {
        this.todoService.getAllByUser(this.currentUser.id).subscribe(todos => { this.todos = todos; });
    }

    nuevo() {
        this.model = {};
        this.edit = false;
    }

    guardarToDo() {
        this.model.user = this.currentUser;
        let fecha = new Date(this.model.date);
        this.model.date = new Date(fecha.getTime() + Math.abs(fecha.getTimezoneOffset()*60000) );

        if(this.edit)
            this.updateToDo(this.model);
        else {
            /*let fecha = this.model.date.split("/");
            this.model.date = new Date(fecha[2], fecha[1] - 1, fecha[0]);*/
            //console.log(this.model.date);
            
            this.todoService.create(this.model)
            .subscribe (
                    data => {
                        // set success message and pass true paramater to persist the message after redirecting to the login page
                        if(data.status == 201) {
                            $('#myModal').modal('toggle');
                            $('#successDiv').show().delay(5000).fadeOut('slow');
                            this.successMessage = "ToDo creado con exito";
                            this.model = {};
                            this.loadAllTodos();
                        }
                    },
                    error => {
                        $('#myModal').modal('toggle');
                        $('#errorDiv').show().delay(5000).fadeOut('slow');
                        this.errorMessage = "No se pudo crear el ToDo";
                        this.model = {};
                    });
        }
    }

    deleteToDo(id: number) {
        this.todoService.delete(id)
        .subscribe (
                data => {
                    $('#confirmDialog').modal('toggle');
                    $('#successDiv').show().delay(5000).fadeOut('slow');;
                    this.successMessage = "ToDo eliminado con exito";
                    this.loadAllTodos();
                    this.removeToDoID = null;
                },
                error => {
                    $('#confirmDialog').modal('toggle');
                    $('#errorDiv').show().delay(5000).fadeOut('slow');
                    this.errorMessage = "No se pudo eliminar el ToDo";
                });
    }

    updateToDo(todo: ToDo) {
        /*let fecha = this.model.date.split("/");
        todo.date = new Date(fecha[2], fecha[1] - 1, fecha[0]);*/

        this.todoService.update(todo)
        .subscribe (
                data => {
                    $('#myModal').modal('toggle');
                    $('#successDiv').show().delay(5000).fadeOut('slow');;
                    this.successMessage = "ToDo actualizado con exito";
                    this.model = {};
                    this.loadAllTodos();
                },
                error => {
                    $('#myModal').modal('toggle');
                    $('#errorDiv').show().delay(5000).fadeOut('slow');;
                    this.errorMessage = "No se pudo actualizar el ToDo";
                    this.model = {};
                });
    }

    cargarModalToDo(todo: ToDo, view: boolean) {
        let todoAux = new ToDo();
        todoAux.id = todo.id;
        todoAux.title = todo.title;
        todoAux.description = todo.description;
        todoAux.date = todo.date;
        todoAux.finish = todo.finish;

        this.model = todoAux;
        this.model.date = this.datePipe.transform(this.model.date, 'yyyy-MM-dd');
        this.edit = !view;
        this.view = view;
        $('#myModal').modal('show');
        //$('#fecha').val(this.model.date);
    }

    openConfirmationDialog(id: number) {
        this.removeToDoID = id;
        $('#confirmDialog').modal('show');
    }
}