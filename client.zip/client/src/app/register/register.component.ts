import { Component } from '@angular/core';
import { Router } from '@angular/router';
 
import { UserService } from '../_services/index';
 
declare var $:any;

@Component({
    moduleId: module.id,
    templateUrl: 'register.component.html',
    styleUrls: ['./register.component.css']
})
 
export class RegisterComponent {
    model: any = {};
    loading = false;
    errorMessage: string;
    successMessage: string;
 
    constructor(
        private router: Router,
        private userService: UserService
    ) { }
 
    register() {
        this.loading = true;
        this.userService.create(this.model)
            .subscribe (
                data => {
                    // set success message and pass true paramater to persist the message after redirecting to the login page
                    //this.router.navigate(['/login']);
                    this.limpiarCampos();
                    this.loading = false;
                    this.successMessage = "Usuario creado con éxito";
                    $('#successDiv').show().delay(5000).fadeOut('slow');
                },
                error => {
                    this.loading = false;
                    this.errorMessage = "El usuario ya existe";
                    $('#errorDiv').show().delay(5000).fadeOut('slow');
                });
    }

    limpiarCampos() {
        this.model = {};
    }
}