export class ToDo {
    id: number;
    title: string;
    description: string;
    date: Date;
    finish: boolean;
}