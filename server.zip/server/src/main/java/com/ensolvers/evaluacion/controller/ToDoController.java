package com.ensolvers.evaluacion.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.util.UriComponentsBuilder;

import com.ensolvers.evaluacion.model.ToDo;
import com.ensolvers.evaluacion.service.IToDoService;

@Controller
@RequestMapping("/api")
@CrossOrigin(origins = {"http://localhost:4200"})
public class ToDoController {

	@Autowired
	private IToDoService todoService;
	
	/*public IToDoService getTodoService() {
		return todoService;
	}*/

	@GetMapping("/todo")
	public ResponseEntity<ToDo> getToDoById(@RequestParam("id") Long id) {
		ToDo todo = this.todoService.getToDoById(id);
		
		return new ResponseEntity<ToDo>(todo, HttpStatus.OK);
	}
	
	@PostMapping("/todo")
	public ResponseEntity<Void> createToDo(@RequestBody ToDo todo, UriComponentsBuilder builder) {
		Boolean success = this.todoService.createToDo(todo);
		if(!success)
			return new ResponseEntity<Void>(HttpStatus.CONFLICT);
		
		HttpHeaders headers = new HttpHeaders();
		headers.setLocation(builder.path("/todo?id={id}").buildAndExpand(todo.getId()).toUri());
		
		return new ResponseEntity<Void>(headers, HttpStatus.CREATED);
	}
	
	@PutMapping("/todo")
	public ResponseEntity<ToDo> updateToDo(@RequestBody ToDo todo) {
		this.todoService.updateToDo(todo);
		
		return new ResponseEntity<ToDo>(todo, HttpStatus.OK);
	}
	
	@DeleteMapping("/todo")
	public ResponseEntity<Void> deleteToDo(@RequestParam("id") Long id) {
		this.todoService.deleteToDo(id);
		
		return new ResponseEntity<Void>(HttpStatus.NO_CONTENT);
	}
	
	@GetMapping("/alltodos")
	public ResponseEntity<List<ToDo>> getAllToDos() {
		List<ToDo> list = this.todoService.getAllToDo();
		
		return new ResponseEntity<List<ToDo>>(list, HttpStatus.OK);
	}
	
	@GetMapping("/alltodosbyuser")
	public ResponseEntity<List<ToDo>> getAllToDosByUser(@RequestParam("id") Long id) {
		List<ToDo> list = this.todoService.getAllToDoByUser(id);
		
		return new ResponseEntity<List<ToDo>>(list, HttpStatus.OK);
	}
}
