package com.ensolvers.evaluacion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EnsolversServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EnsolversServerApplication.class, args);
	}
}
