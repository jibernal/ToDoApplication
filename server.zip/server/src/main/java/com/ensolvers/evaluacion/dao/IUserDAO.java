package com.ensolvers.evaluacion.dao;

import com.ensolvers.evaluacion.model.User;

public interface IUserDAO {

	public void createUser(User user);
	public User getUserById(Long id);
	public User getUser(String username, String password);
	public Boolean userExists(String username);
}
