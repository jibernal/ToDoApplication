package com.ensolvers.evaluacion.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ensolvers.evaluacion.dao.IToDoDAO;
import com.ensolvers.evaluacion.model.ToDo;

@Service
public class ToDoService implements IToDoService {

	@Autowired
	private IToDoDAO todoDAO;
	
	public IToDoDAO getToDoDAO() {
		return this.todoDAO;
	}
	
	@Override
	public synchronized Boolean createToDo(ToDo todo) {
		this.getToDoDAO().createToDo(todo);
		
		return true;
	}

	@Override
	public ToDo getToDoById(Long id) {
		return this.getToDoDAO().getToDoById(id);
	}

	@Override
	public void updateToDo(ToDo todo) {
		this.getToDoDAO().updateToDo(todo);
	}

	@Override
	public void deleteToDo(Long id) {
		this.getToDoDAO().deleteToDo(id);
	}

	@Override
	public List<ToDo> getAllToDo() {
		return this.getToDoDAO().getAllToDo();
	}
	
	@Override
	public List<ToDo> getAllToDoByUser(Long id) {
		return this.getToDoDAO().getAllToDoByUser(id);
	}

}
