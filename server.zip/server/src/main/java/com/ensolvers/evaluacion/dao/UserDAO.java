package com.ensolvers.evaluacion.dao;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ensolvers.evaluacion.model.User;

@Transactional
@Repository
public class UserDAO implements IUserDAO {

	@PersistenceContext
	private EntityManager entityManager;
	
	/*public EntityManager getEntityManager() {
		return entityManager;
	}*/

	@Override
	public void createUser(User user) {
		this.entityManager.persist(user);
	}
	
	@Override
	public User getUserById(Long id) {
		return this.entityManager.find(User.class, id);
	}

	@Override
	public User getUser(String username, String password) {
		return this.entityManager.createQuery(
				  "SELECT u from User u WHERE u.username = :username AND u.password = :password", User.class).
				  setParameter("username", username).setParameter("password", password).getSingleResult();
	}
	
	@Override
	public Boolean userExists(String username) {
		String hql = "FROM User u WHERE u.username = :username";
		int count = entityManager.createQuery(hql).setParameter("username", username).getResultList().size();
		
		return count > 0 ? true : false;
	}
}
