package com.ensolvers.evaluacion.service;

import com.ensolvers.evaluacion.model.User;

public interface IUserService {

	public Boolean createUser(User user);
	public User getUserById(Long id);
	public User getUser(String username, String password);
	public Boolean userExists(String username);
}
