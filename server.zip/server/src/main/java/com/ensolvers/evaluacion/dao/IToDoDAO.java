package com.ensolvers.evaluacion.dao;

import java.util.List;

import com.ensolvers.evaluacion.model.ToDo;

public interface IToDoDAO {

	public void createToDo(ToDo todo);
	public ToDo getToDoById(Long id);
	public void updateToDo(ToDo todo);
	public void deleteToDo(Long id);
	public List<ToDo> getAllToDo();
	public List<ToDo> getAllToDoByUser(Long id);
}
