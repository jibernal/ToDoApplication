package com.ensolvers.evaluacion.dao;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.ensolvers.evaluacion.model.ToDo;

@Transactional
@Repository
public class ToDoDAO implements IToDoDAO {

	@PersistenceContext
	private EntityManager entityManager;
	
	public EntityManager getEntityManager() {
		return entityManager;
	}

	@Override
	public void createToDo(ToDo todo) {
		this.getEntityManager().persist(todo);
	}

	@Override
	public ToDo getToDoById(Long id) {
		return this.getEntityManager().find(ToDo.class, id);
	}

	@Override
	public void updateToDo(ToDo todo) {
		ToDo td = this.getToDoById(todo.getId());
		td.setTitle(todo.getTitle());
		td.setDescription(todo.getDescription());
		td.setDate(todo.getDate());
		td.setFinish(todo.getFinish());
		
		this.getEntityManager().flush();
	}

	@Override
	public void deleteToDo(Long id) {
		this.getEntityManager().remove(this.getToDoById(id));
	}

	@Override
	public List<ToDo> getAllToDo() {
		String hql = "FROM ToDo AS td ORDER BY td.date ASC";
		
		return (List<ToDo>) this.getEntityManager().createQuery(hql).getResultList();
	}
	
	@Override
	public List<ToDo> getAllToDoByUser(Long id) {
		String hql = "FROM ToDo AS td WHERE td.user.id = :userId ORDER BY td.date ASC";
		
		return (List<ToDo>) this.getEntityManager().createQuery(hql).setParameter("userId", id).getResultList();
	}

}
