package com.ensolvers.evaluacion.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ensolvers.evaluacion.dao.IUserDAO;
import com.ensolvers.evaluacion.model.User;

@Service
public class UserService implements IUserService {

	@Autowired
	private IUserDAO userDAO;
	
	/*public IUserService getUserDAO() {
		return this.userDAO;
	}*/
	
	@Override
	public synchronized Boolean createUser(User user) {
		if(!this.userExists(user.getUsername())) {
			this.userDAO.createUser(user);
		
			return true;
		} else
			return false;
	}

	@Override
	public User getUserById(Long id) {
		return this.userDAO.getUserById(id);
	}
	
	@Override
	public User getUser(String username, String password) {
		return this.userDAO.getUser(username, password);
	}
	
	@Override
	public Boolean userExists(String username) {
		return this.userDAO.userExists(username);
	}
}
